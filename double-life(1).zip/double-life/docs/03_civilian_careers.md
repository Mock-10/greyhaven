# 03 — Civilian Careers

## How jobs work
- **Start:** on the first day the player picks one of four starting jobs. All four have similar pay but play very differently.
- **Switching** is free at any time from the job board or a phone call. **Rank is kept separately for every job**, so you can go back to an old job at the rank you left it.
- **Shift:** clock in between 08:00 and 10:00 (late after 09:00: −20% pay for that shift). A shift is **3–4 key tasks**, each one a minigame (see 06), taking about 3–4 real minutes in total. Then clock out and get paid in clean cash.
- **Weekend side gigs** (Saturday and Sunday): optional short gigs at 60% of your rank's pay. They give no promotion XP.
- **Missed shift:** no pay, −5 promotion XP. A bribe to HR can cover it (see 02).

## Performance and promotion
Each task is graded **Poor, OK, Good or Excellent** from the minigame result. Promotion XP per shift is the sum of its tasks:

| Shift result | XP |
|---|---|
| Mostly poor | 6 |
| Mostly OK | 9 |
| Mostly good | 11 |
| Mostly excellent | 14 |

| Rank | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| Pay per shift (clean) | $180 | $260 | $370 | $510 | $700 |
| XP to reach the next rank | 40 | 70 | 110 | 160 | — |
| One-time promotion bonus | — | $250 | $500 | $900 | $1,500 |

A dedicated player reaches rank 2 around day 4, rank 3 around day 12, rank 4 around day 26 and rank 5 around day 40.

## Effect of an arrest on your career
These apply to **every** job, because the record follows the person:
1. **Promotion freeze** for 3 in-game days: no promotion XP is earned. Lifting it early costs a $600 HR bribe.
2. **Missed shifts while jailed** pay nothing and cost −5 XP each. A $150 HR bribe covers each one.
3. **Extra work for 2 days after release:** each shift has 1 extra task, and the XP requirement for your current rank goes up by +10% until the end of day 2.
4. The weekly **clean-record bonus** (+15% of the week's pay) is lost for that week.

Getting identified on camera but never arrested does **not** affect your job. Only arrests count.

## The jobs
Each job has its own minigames (06), a rank ladder, and **insider perks** that feed into crime. This is how the two lives connect.

### Starting jobs
**Office Worker** — Downtown tower. Ranks: Clerk → Analyst → Senior Analyst → Manager → Director.
- Tasks: *Filing* (sort papers into trays), *Data entry* (type sequence), *Stamp and sign* (timing), *Meeting* (choose dialogue to keep the boss happy; rank 3+).
- Insider perks: rank 2 gets a building **key card** for after-hours access to the tower. Rank 3 gets **tip-offs**: armored truck route times appear on the map. Rank 4 gets **expense account**: −10% on legal purchases.

**Car Mechanic** — garage in Industrial. Ranks: Apprentice → Mechanic → Senior → Shop Lead → Owner's Partner.
- Tasks: *Diagnose* (find the faulty part), *Bolt torque* (timing), *Tyre change* (sequence), *Respray* (even sweep).
- Insider perks: rank 1 gets **−20% repairs and upgrades**. Rank 2 lets you **respray stolen cars legally** for $400 (clears "hot" status). Rank 4 makes hideout **garage add-ons 30% cheaper**.

**Lumberjack** — lumber camp in the Outskirts. Ranks: Hand → Feller → Rigger → Crew Boss → Camp Boss.
- Tasks: *Chop* (swing timing), *Fell direction* (aim), *Load logs* (stacking), *Haul* (drive the log truck to the mill).
- Insider perks: rank 2 gets a **truck license** to borrow the log truck. Rank 3 unlocks **hidden compartments**: shipments carried in the log truck lose 50% less value from damage and pass police stops. Rank 4 marks **remote drops** in the forest on the map.

**Delivery Driver** — depot in Suburbs. Ranks: Courier → Driver → Senior Driver → Route Planner → Depot Manager.
- Tasks: *Load van* (stacking), *Route* (pick the shortest of 3 routes), *Doorstep* (timed hand-off, finding the right door), *Signature* (trace).
- Insider perks: rank 1 gives a **uniform** that makes witnesses 30% slower to call in your daytime crimes in Suburbs. Rank 2 gives **route knowledge**: +20% time on smuggling deliveries. Rank 3 lets you see **house occupancy**, which shows the best burglary targets.

### Later jobs (unlocked from the job board after day 5)
You are **never fired** from any job, however many arrests you have (decided). Arrests only cause the effects listed above.

**Security Guard** — banks and stores in Downtown. Ranks: Guard → Senior Guard → Supervisor → Site Lead → Head of Security.
- Tasks: *Patrol* (reach checkpoints in time), *Monitor cameras* (spot the shoplifter), *ID check* (spot the fake).
- Insider perks: rank 2 shows **camera blind spots** as a faint overlay. Rank 3 can **disable cameras** in stores for 60 seconds. Rank 4 shows **vault schedules**, which make heist prep shorter.

**Road Worker** — city crews, all districts. Ranks: Labourer → Operator → Foreman → Supervisor → Site Manager.
- Tasks: *Paint lines* (steady sweep), *Jackhammer* (rhythm), *Traffic control* (stop/go timing), *Cone layout* (placement).
- Insider perks: rank 2 gives **maintenance tunnels**: manhole shortcuts that lose pursuers (break line of sight). Rank 3 lets you **close a road** to set up an armored truck ambush. Rank 4 gives a **high-vis disguise**: −1 star at the moment you put it on (once per chase).

**Farmer** — Old Pete's farm, Outskirts. Ranks: Farmhand → Tractor Driver → Field Hand Lead → Foreman → Farm Partner.
- Tasks: *Plough / plant* (drive the tractor along furrow lines), *Harvest* (timing), *Sort produce* (sorting), *Irrigate* (open valves in sequence).
- Insider perks: rank 1 means you **hear the night planes**: a radar ping when an airdrop lands in a nearby field. Rank 2 gives the **airdrop schedule**: drop times and fields are marked a day ahead. Rank 3 gives a **barn stash** on the farm, a safe place to hide airdrop crates and product. Rank 4 gives **field access**: police never search the farm grounds.
- Design intent (the user's idea): working the farm teaches the player that product arrives through the fields, so the honest job naturally reveals the airdrop crime route.

**Scrap Yard Worker** — legal scrap yard, Industrial. Ranks: Sorter → Crane Operator → Crusher Operator → Yard Lead → Yard Manager.
- Tasks: *Crane magnet* (position and drop), *Crush* (timing), *Sort metal* (sorting by type), *Weigh-in* (read the scale and enter the value).
- Insider perks: rank 1 lets you **hear about chop shop deals**: the chop shop pays +15%. Rank 2 lets you **crush a hot car legally**: it is destroyed, its "hot" status is cleared, and if unseen it clears 1★ (once per chase). Rank 3 gives **−25% on used parts** for upgrades. Rank 4 lets you run the **chop bay at the yard** without owning a hideout add-on.
